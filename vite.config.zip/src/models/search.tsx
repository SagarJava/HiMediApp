export interface SearchModel {
    id: number;
    name: string;
    href: string;
    serviceName: string;
  }