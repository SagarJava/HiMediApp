export interface PricingModel {
    pricing_id: number;
    pricing_name: string;
    pricing_description: string;
  }
  