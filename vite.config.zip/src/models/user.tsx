export interface UserModel {
    id: number;
    name: string;
    description: string;
    contact: number;
  }