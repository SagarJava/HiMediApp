import React from 'react';
import './splash.css'; // Add custom styles

const OnBoard2: React.FC = () => {
  return (
    <div className="splash-container">
      <h1 className="logo">Find Best Insurance , Hospitals & more near you .</h1>
      <p className="tagline">Lorem ipsum is a placeholder text commonly used to demonstrate the visual.</p>
    </div>
  );
};

export default OnBoard2;
